import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:provider/provider.dart'; 
import 'screens/signup_screen.dart'; 
// 1. هنا المسار اللي إنت أكدت عليه
import 'screens/login_screens.dart'; 
import 'services/auth_service.dart'; 

void main() async {
  WidgetsFlutterBinding.ensureInitialized(); 

  await Firebase.initializeApp(
    options: const FirebaseOptions(
      apiKey: "AIzaSyCPQk2dxkvESbHs77-c0nK_-NBEnxvAkMI", 
      appId: "1:968823956652:android:3c7d63e66cf6909e222b09", 
      messagingSenderId: "968823956652",
      projectId: "laza-ecommerce-3c43c",
      storageBucket: "laza-ecommerce-3c43c.firebasestorage.app",
    ),
  ); 

  runApp(
    MultiProvider(
      providers: [
        Provider<AuthService>(create: (_) => AuthService()),
      ],
      child: const MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Laza E-commerce',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      // 2. شيلت كلمة const من هنا عشان لو صفحة الـ Login فيها controllers ميعملش Error
      home: LoginScreen(), 
    );
  }
}