import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class CartScreen extends StatelessWidget {
  const CartScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;

    return Scaffold(
      appBar: AppBar(
        title: const Text("My Cart", style: TextStyle(fontWeight: FontWeight.bold)),
        centerTitle: true,
      ),
      body: user == null
          ? const Center(child: Text("Please login first"))
          : StreamBuilder(
              stream: FirebaseFirestore.instance
                  .collection('carts')
                  .doc(user.uid)
                  .collection('items')
                  .snapshots(),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                }
                
                if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                  // تحسين الـ Empty State (مطلوب في بند 5.8)
                  return Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.shopping_bag_outlined, size: 100, color: Colors.grey[400]),
                        const SizedBox(height: 15),
                        const Text("Your cart is empty", 
                          style: TextStyle(fontSize: 18, color: Colors.grey, fontWeight: FontWeight.w500)),
                      ],
                    ),
                  );
                }

                final docs = snapshot.data!.docs;

                // حساب المجموع الكلي
                double total = 0;
                for (var doc in docs) {
                  total += doc['price'];
                }

                return Column(
                  children: [
                    Expanded(
                      child: ListView.builder(
                        padding: const EdgeInsets.symmetric(horizontal: 10),
                        itemCount: docs.length,
                        itemBuilder: (context, index) {
                          final data = docs[index].data() as Map<String, dynamic>;
                          return Card(
                            margin: const EdgeInsets.symmetric(vertical: 8),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
                            child: ListTile(
                              contentPadding: const EdgeInsets.all(10),
                              leading: ClipRRect(
                                borderRadius: BorderRadius.circular(10),
                                child: Image.network(data['imageUrl'], width: 60, height: 60, fit: BoxFit.cover),
                              ),
                              title: Text(data['title'], style: const TextStyle(fontWeight: FontWeight.bold), maxLines: 1, overflow: TextOverflow.ellipsis),
                              subtitle: Text("\$${data['price']}", style: const TextStyle(color: Colors.green, fontWeight: FontWeight.bold)),
                              trailing: IconButton(
                                icon: const Icon(Icons.delete_outline, color: Colors.red),
                                onPressed: () {
                                  FirebaseFirestore.instance
                                      .collection('carts')
                                      .doc(user.uid)
                                      .collection('items')
                                      .doc(docs[index].id)
                                      .delete();
                                },
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                    // منطقة الـ Checkout (بند 5.5)
                    Container(
                      padding: const EdgeInsets.all(25.0),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: const BorderRadius.vertical(top: Radius.circular(25)),
                        boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 10, spreadRadius: 2)],
                      ),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const Text("Total:", style: TextStyle(fontSize: 18, color: Colors.grey)),
                              Text("\$${total.toStringAsFixed(2)}", style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                            ],
                          ),
                          const SizedBox(height: 20),
                          SizedBox(
                            width: double.infinity,
                            child: ElevatedButton(
                              style: ElevatedButton.styleFrom(
                                backgroundColor: const Color(0xFF9775FA), // لون Laza الشهير
                                foregroundColor: Colors.white,
                                padding: const EdgeInsets.symmetric(vertical: 15),
                                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                              ),
                              onPressed: () async {
                                // Mock Checkout (بند 5.5)
                                final batch = FirebaseFirestore.instance.batch();
                                for (var doc in docs) {
                                  batch.delete(doc.reference);
                                }
                                await batch.commit();
                                
                                // إظهار رسالة النجاح والرجوع للهوم (Success Screen Mock)
                                if (context.mounted) {
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    const SnackBar(content: Text("Order Placed Successfully! ✅"), backgroundColor: Colors.green),
                                  );
                                  Navigator.pop(context); // يرجع للهوم بعد النجاح
                                }
                              },
                              child: const Text("Checkout", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                            ),
                          ),
                        ],
                      ),
                    )
                  ],
                );
              },
            ),
    );
  }
}